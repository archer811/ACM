#include <iostream>
using namespace std;

const int maxn = 600005;

int tp[maxn], l[maxn], f[maxn];
int d[maxn], g[maxn], q[maxn];
int n, m, p, ps;

struct edge {
    int s, t, ne;
    bool ok;
    inline void read() {scanf("%d%d", &s, &t); t += n;}
    inline void add(int i) {ne = tp[s]; tp[s] = i;}
    inline void change() {if (ok = g[t] == s) swap(s, t);}
    inline char ck() {return f[s] != f[t] ? ok ? '1' : '2' : '0';}
} e[maxn];

bool bfs()
{
    memset(&d[1], 0, n << 3);
    int ff = 0, rr = 0, ret = 0;
    for (int i = 1; i <= n; ++i)
        if (!g[i]) q[++rr] = i;
    while (ff < rr) {
        int i = q[++ff];
        if (i > n) d[q[++rr] = g[i]] = d[i] + 1;
        else
            for (int j = tp[i]; j; j = e[j].ne) {
                int k = e[j].t;
                if (d[k]) continue;
                d[k] = d[i] + 1;
                if (g[k]) q[++rr] = k;
                else ret = 1;
            }
    }
    return ret;
}

bool find(int i)
{
    for (int j = tp[i]; j; j = e[j].ne) {
        int k = e[j].t;
        if (d[i] + 1 != d[k]) continue;
        d[k] = -1;
        if (!g[k] || find(g[k])) {
            g[i] = k; g[k] = i; return true;
        }
    }
    return false;
}

void dfs(int i)
{
    int pp = l[i] = ++p;
    q[p] = i;
    for (int j = tp[i]; j; j = e[j].ne) {
        int k = e[j].t;
        if (!l[k]) dfs(k);
        if (!f[k]) l[i] <?= l[k];
    }
    if (l[i] == pp) {
        ++ps;
        while (p >= pp) f[q[p--]] = ps;
    }
}

int main()
{
    freopen("cupid.in", "r", stdin);
    freopen("cupid.out", "w", stdout);

    cin >> n >> m;
    for (int i = 1; i <= m; ++i)
        e[i].read(), e[i].add(i);
    while (bfs())
        for (int i = 1; i <= n; ++i)
            if (!g[i]) find(i);
    memset(&tp[1], 0, n << 2);
    for (int i = 1; i <= m; ++i)
        e[i].change(), e[i].add(i);
    for (int i = 1; i <= 2 * n; ++i)
        if (!l[i]) dfs(i);
    for (int i = 1; i <= m; ++i)
        printf("%c", e[i].ck());
    
    return 0;
}
